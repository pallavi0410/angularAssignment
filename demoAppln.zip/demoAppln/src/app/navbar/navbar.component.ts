import { Component, OnInit } from '@angular/core';
import { SessionStorageService } from 'angular-web-storage';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private sessionService: SessionStorageService, public toastr: ToastrService) { }

  ngOnInit() {
  }

  logoutUser() {
    this.sessionService.remove('userData');
    this.toastr.success('Successfully Logged out');
  }

}
