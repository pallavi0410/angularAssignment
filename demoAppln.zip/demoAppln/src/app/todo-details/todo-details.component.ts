import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-todo-details',
  templateUrl: './todo-details.component.html',
  styleUrls: ['./todo-details.component.css']
})
export class TodoDetailsComponent implements OnInit {
  dialogData: any;

  constructor(public dialogRef: MatDialogRef<TodoDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
      this.dialogData = data.rowData;
      console.log('Dialog data', this.dialogData);
    }

  ngOnInit() {
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

}
