import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../data.service';
import { MatTableDataSource, MatSort } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { TodoDetailsComponent } from '../todo-details/todo-details.component';
import { SessionStorageService } from 'angular-web-storage';

// export interface ToDoList {
//   id: number;
//   userId: number;
//   title: string;
//   completed: boolean;
// }

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  tableDataSource: Array<object>;
  displayedColumns: string[] = ['taskId', 'userId', 'title', 'status', 'action'];
  dataSource: any;
  rowData: any;

  @ViewChild(MatSort) sort: MatSort;


  constructor(private dataService: DataService, public dialog: MatDialog, private sessionService: SessionStorageService) { }

  ngOnInit() {
    console.log('dksmlf',this.sessionService.get('userData'));   
    this.dataService.getDataList().subscribe(response => {
      console.log('all data', response);
      this.tableDataSource = response;
      this.dataSource = new MatTableDataSource(this.tableDataSource);
      this.dataSource.sort = this.sort;
    });
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  openDetailsDialog(rowData: any): void {
    console.log('rowData', rowData);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.maxWidth = '500px';
    dialogConfig.width = '400px';
    dialogConfig.maxHeight = '500px';
    dialogConfig.height = '350px';
    dialogConfig.data = {
      'rowData': rowData
    }
    this.dialog.open(TodoDetailsComponent, dialogConfig);
  }

}
