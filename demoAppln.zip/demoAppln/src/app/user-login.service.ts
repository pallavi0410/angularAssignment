import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserLoginService {

  private isUserLoggedIn;

  constructor() {
    this.isUserLoggedIn = false;
  }

  setLoggedInUser() {
    this.isUserLoggedIn = true;
  }

  getLoggedInUser() {
    return this.isUserLoggedIn;
  }
}

