import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UserLoginService } from '../user-login.service';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  
  form: FormGroup;
  userName: string;
  password: string;
  email: any;
  userDetails: { 'email': any; 'userName': any; 'password': any; };

  // tslint:disable-next-line:max-line-length
  constructor(private formBuilder: FormBuilder, public router: Router, public toastr: ToastrService, private userService: UserLoginService, private sessionService: SessionStorageService) {
    this.form = this.formBuilder.group({
      userName: [null, Validators.compose([Validators.required, Validators.minLength(3)])],
      email: [null, Validators.compose([Validators.required, Validators.email, Validators.minLength(6)])],
      password: [null, Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(16)])],
    });
  }

  ngOnInit() {
  }

  addPost(formData) {
    console.log('form data', formData);
    if (formData.email === 'test@gmail.com' && formData.userName === 'testUser' &&
      formData.password === 'pass@123') {
      this.userService.setLoggedInUser();
      this.userDetails = {
        'email': formData.email,
        'userName': formData.userName,
        'password': formData.password
      };
      this.sessionService.set('userData', this.userDetails);
      this.router.navigate(['/dashboard']);
      this.toastr.success('', 'Successfully Logged In');
    } else {
      this.toastr.error('Please Try Again', 'Invalid Credentials');
    }
  }

}



